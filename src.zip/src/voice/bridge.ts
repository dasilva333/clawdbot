
import { VoiceManager } from "./manager.js";
import { MiniCPMTTSProvider } from "../provider.js";
import type { PluginLogger } from "openclaw";

export class VoiceBridge {
  private manager: VoiceManager;
  private provider: MiniCPMTTSProvider;
  private logger: PluginLogger;

  constructor(manager: VoiceManager, provider: MiniCPMTTSProvider, logger: PluginLogger) {
    this.manager = manager;
    this.provider = provider;
    this.logger = logger;
  }

  async speak(guildId: string, text: string, voice?: string) {
    try {
      this.logger.info(`[VoiceBridge] Generating stream for guild ${guildId}: "${text.slice(0, 50)}..."`);
      const stream = await this.provider.synthesizeStream(text, voice);
      this.manager.playStream(guildId, stream);
    } catch (error) {
      this.logger.error(`[VoiceBridge] Failed to play voice in ${guildId}: ${error}`);
    }
  }
}
