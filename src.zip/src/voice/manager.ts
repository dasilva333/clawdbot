
import {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
  type VoiceConnection,
  type AudioPlayer,
} from "@discordjs/voice";
import { Readable } from "node:stream";
import type { PluginLogger } from "openclaw";

export interface VoiceSession {
  connection: VoiceConnection;
  player: AudioPlayer;
  channelId: string;
  guildId: string;
}

export class VoiceManager {
  private sessions = new Map<string, VoiceSession>();
  private logger: PluginLogger;

  constructor(logger: PluginLogger) {
    this.logger = logger;
  }

  async join(guildId: string, channelId: string, adapterCreator: any) {
    const existing = this.sessions.get(guildId);
    if (existing) {
      if (existing.channelId === channelId) return existing;
      existing.connection.destroy();
    }

    const connection = joinVoiceChannel({
      channelId,
      guildId,
      adapterCreator,
      selfDeaf: false,
      selfMute: false,
    });

    const player = createAudioPlayer();
    connection.subscribe(player);

    connection.on(VoiceConnectionStatus.Disconnected, async () => {
      try {
        await Promise.race([
          entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
          entersState(connection, VoiceConnectionStatus.Connecting, 5_000),
        ]);
        // Reconnected
      } catch (error) {
        this.logger.warn(`[Voice] Connection to ${guildId} lost permanently`);
        connection.destroy();
        this.sessions.delete(guildId);
      }
    });

    const session: VoiceSession = { connection, player, channelId, guildId };
    this.sessions.set(guildId, session);
    
    this.logger.info(`[Voice] Joined channel ${channelId} in guild ${guildId}`);
    return session;
  }

  playStream(guildId: string, stream: Readable) {
    const session = this.sessions.get(guildId);
    if (!session) {
      this.logger.warn(`[Voice] Cannot play stream: no active session for guild ${guildId}`);
      return;
    }

    const resource = createAudioResource(stream);
    session.player.play(resource);
  }

  leave(guildId: string) {
    const session = this.sessions.get(guildId);
    if (session) {
      session.connection.destroy();
      this.sessions.delete(guildId);
      this.logger.info(`[Voice] Left voice in guild ${guildId}`);
    }
  }
}
